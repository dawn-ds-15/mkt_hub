---
name: MKT Hub
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#444651'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#340081'
  on-tertiary: '#ffffff'
  tertiary-container: '#4e03b8'
  on-tertiary-container: '#b89cff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  success: '#10B981'
  warning: '#F59E0B'
  danger: '#EF4444'
  chart-blue: '#1E3A8A'
  chart-yellow: '#FBBF24'
  chart-orange: '#F97316'
  chart-purple: '#A855F7'
  chart-green: '#22C55E'
  background-subtle: '#F8FAFC'
  sidebar-bg: '#0F172A'
  border-light: '#E2E8F0'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-display:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  data-subtext:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-margin: 24px
  gutter: 16px
  widget-padding: 20px
  sidebar-width: 260px
  topbar-height: 64px
---

## Brand & Style

The design system is engineered for **Marketing Operations (MarOps)**, where data density and operational speed are paramount. The brand personality is **authoritative, analytical, and highly efficient**, aiming to evoke a sense of "Operational Control" and "Data Clarity."

The chosen design style is **Corporate / Modern** with a focus on **Data-Centric Minimalism**. It prioritizes legibility and information architecture over decorative elements.

### Key Principles
- **Clarity over Decoration:** Every UI element must serve a functional purpose in data visualization or navigation.
- **Hierarchical Density:** Use white space strategically to prevent cognitive overload in data-heavy views while maintaining a compact layout for efficiency.
- **Trustworthy Professionalism:** A stable, blue-dominant palette combined with clear status indicators for KPI tracking.
- **Modular Architecture:** A card-based layout ensures that distinct modules (Leads, Projects, Expenses) feel like cohesive parts of a singular "Command Center."

## Colors

The palette is anchored by **Trustworthy Deep Blue (#1E3A8A)**, representing the core "Source of Truth." 

### Functional Application
- **Primary:** Used for primary actions, active navigation states, and brand headers.
- **Semantic States:** Success (Green), Warning (Amber), and Danger (Red) are strictly reserved for KPI performance indicators (BR-009) and task alerts (BR-010).
- **Chart Palette:** A distinct 5-color categorical palette is used for data visualization (Blue, Yellow, Orange, Purple, Green) to ensure clear differentiation in grouped bar and donut charts.
- **Neutrals:** Professional cool-grays handle the heavy lifting for backgrounds (`#F8FAFC`), borders (`#E2E8F0`), and secondary text.
- **Sidebar:** The sidebar utilizes a dark-neutral background (`#0F172A`) to distinguish the navigation and global filter area from the primary content workspace.

## Typography

The system uses **Inter** exclusively to leverage its exceptional legibility in high-density data environments. 

### Usage Guidance
- **Headlines:** Use `headline-lg` for module titles (e.g., "Dashboard Overview") and `headline-md` for widget titles.
- **Data Display:** Specialized `data-display` tokens are for primary KPI numbers within cards (e.g., Actual Lead counts).
- **Labels:** `label-md` uses uppercase and slight tracking for sidebar headers and table headers.
- **Scaling:** On mobile, reduce `headline-lg` to 24px/32px to accommodate narrow viewports. Data tables should prioritize `body-sm` to maximize information density without losing readability.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. The sidebar and topbar are fixed components, while the main content area utilizes a fluid grid that adapts to the available screen width.

### Grid System
- **Desktop:** A 12-column grid with 16px gutters.
- **KPI Cards:** Specifically arranged in a 7-column horizontal row on wide screens, reflowing to a 4x2 grid on smaller monitors.
- **Widgets:** Built as modular cards that occupy 3, 4, 6, or 12 columns depending on content complexity (e.g., Alert list is 4-columns, Funnel is 8-columns).

### Responsive Reflow
- **Tablet:** Sidebar collapses to an icon-only rail. Content margins reduce to 16px.
- **Mobile:** Single column vertical stack. The Global Filter moves from the sidebar to a collapsible top drawer.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Subtle Ambient Shadows**.

- **Surface Tier 1 (Background):** `#F8FAFC` - The lowest level, used for the main workspace.
- **Surface Tier 2 (Cards/Widgets):** `#FFFFFF` - All data containers. These use a very soft, diffused shadow (`box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px 0 rgba(0, 0, 0, 0.03)`) to separate them from the background.
- **Surface Tier 3 (Modals/Dropdowns):** Elevated with a medium shadow to indicate interactivity and focus.

**Borders:** Use `#E2E8F0` for card outlines and table dividers to maintain structural integrity without the heaviness of dark lines.

## Shapes

The design system uses a **Soft (0.25rem)** roundedness profile to maintain a crisp, professional aesthetic that feels modern but not overly casual.

- **Buttons & Inputs:** `rounded` (4px) for a precise, geometric feel.
- **Cards & Widgets:** `rounded-lg` (8px) to soften the large data containers and make the layout more approachable.
- **Status Badges:** `rounded-full` (pill-shaped) to distinguish status indicators from clickable buttons.

## Components

### Global Filter
Located in the sidebar, this uses a high-contrast treatment (light text on dark background). 
- **Selectors:** Year, Project Type, Status, and Stakeholder are styled as borderless, dark-themed dropdowns to maintain the sidebar's visual unity.

### KPI Cards
- **Structure:** Metric Name (Top-left), Main Value (Center), Trend/Plan % (Bottom-left), and a 4px tall Progress Bar at the absolute bottom of the card.
- **Color Logic:** Progress bar color is mapped to `% vs Plan` (Green: ≥100%, Yellow: 80-99%, Red: <80%).

### Buttons
- **Primary:** Filled `#1E3A8A` with white text.
- **Secondary:** Outlined with `#1E3A8A` and `#E2E8F0`.
- **Status Badges:** Small, semi-transparent background with high-opacity text (e.g., Success badge: 10% opacity Green background with 100% opacity Green text).

### Form Inputs
- **Inputs:** White background, 1px `#E2E8F0` border, `Inter Body-md` text. On focus, the border shifts to Primary `#1E3A8A` with a 2px soft outer glow.
- **Lists & Tables:** Compact padding (8px - 12px) with subtle zebra striping for improved row scanning.

### Alerts
- **High Urgency:** Light red background, thick 4px left-border of `#EF4444`.
- **Medium Urgency:** Light yellow background, thick 4px left-border of `#F59E0B`.