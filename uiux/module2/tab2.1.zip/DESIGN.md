---
name: Blueprint SaaS Wireframe
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#1e1200'
  on-tertiary: '#ffffff'
  tertiary-container: '#35260c'
  on-tertiary-container: '#a38c6a'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#fadfb8'
  tertiary-fixed-dim: '#ddc39d'
  on-tertiary-fixed: '#271902'
  on-tertiary-fixed-variant: '#564427'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  sidebar_width: 260px
  container_max_width: 1440px
  gutter: 1.5rem
  margin_mobile: 1rem
  margin_desktop: 2rem
  stack_sm: 0.5rem
  stack_md: 1rem
  stack_lg: 2rem
---

## Brand & Style
This design system prioritizes functional clarity and structural hierarchy over aesthetic flourish, adopting a **refined wireframe aesthetic**. It is specifically engineered for a B2B Marketing Management Hub where data density and task orchestration are paramount. 

The style sits at the intersection of **Minimalism** and **Modern Corporate**, utilizing a monochromatic "slate-and-white" palette to eliminate visual noise and focus the user's attention on workflow and content status. The emotional response is one of organized efficiency, reliability, and precision. Every element is intentionally "low-fidelity" in color but "high-fidelity" in alignment and spacing, allowing the marketing logic to lead the experience.

## Colors
The palette is intentionally restrained to maintain a "blueprint" feel. 
- **Primary (Slate 800):** Reserved for high-level structural elements like the sidebar, primary action buttons, and main headings.
- **Surface (White & Slate 50):** White is used for the main content canvas and cards to provide maximum contrast. Slate 50 is used for background fills and subtle section grouping.
- **Borders (Slate 200):** Used for all structural dividers, table rows, and input fields.
- **Functional Accents:** Vibrant colors are used exclusively for status indicators (Overdue, Near Deadline, Done) to ensure they pop against the neutral background.

## Typography
The design system utilizes **Inter** for its exceptional legibility in data-heavy environments. The typographic scale is optimized for information density.
- **Headlines:** Use Slate 800. Bold weights differentiate views and section headers.
- **Body:** Use Slate 600 for secondary text and Slate 900 for primary content.
- **Labels:** Small caps or medium weights are used for table headers and metadata to provide clear categorization without overwhelming the body text.

## Layout & Spacing
The layout follows a **Fixed-Fluid hybrid grid**:
- **Sidebar:** Fixed 260px width, docked to the left.
- **Main Canvas:** Fluid with a max-width of 1440px for comfortable reading on ultra-wide monitors.
- **Grid:** Uses an 8px base unit. Data tables and Kanban boards should use a 16px (1rem) gutter to maintain a tight, professional information density.
- **Breakpoints:** 
  - **Desktop (1024px+):** Full sidebar visible. 
  - **Tablet (768px - 1023px):** Sidebar collapses to icons only; 2-column Kanban.
  - **Mobile (<768px):** Sidebar hidden (hamburger menu); stacked list views instead of tables/Kanban.

## Elevation & Depth
This design system avoids heavy shadows to maintain its wireframe aesthetic. Depth is communicated through **Tonal Layers** and **Crisp Outlines**:
- **Level 0 (Background):** Slate 50.
- **Level 1 (Cards/Tables):** White surface with a 1px Slate 200 border. No shadow.
- **Level 2 (Modals/Slide-overs):** White surface with a very subtle, diffused shadow (0px 10px 15px -3px rgba(0,0,0,0.05)) and a Slate 300 border to distinguish it from the background.
- **Active States:** Subtle Slate 100 fills are used to indicate selected rows or hovered items.

## Shapes
A **Soft (0.25rem)** roundedness is applied consistently across all interactive elements.
- **Buttons & Inputs:** 4px (0.25rem) radius.
- **Cards & Kanban Columns:** 8px (0.5rem) radius for a slightly softer container feel.
- **Status Chips:** Fully rounded (pill-shaped) to distinguish them from actionable buttons.

## Components
- **Sidebar Navigation:** Dark background (Slate 800 or 900), icons paired with Label-MD text. Active state uses a Slate 700 background fill and a 3px left-accent border in primary blue or white.
- **Data Tables:** Header cells use Slate 50 background with Label-SM (Uppercase) text. Rows are 48px height with 1px bottom borders. Hover state: Slate 50.
- **Kanban Cards:** White background, 1px border. Vertical stacking of elements: Title (Headline-SM), Description (Body-MD), Footer with Status Chip and Avatar.
- **Tabs:** Underline style. Active tab has a 2px Slate 800 bottom border and bolded text.
- **Slide-over Panels:** Slide in from the right, covering 400px–600px of the screen. Include a clear 'X' close button and a Slate 900 header bar.
- **Status Chips:** 
  - Overdue: Red-100 background, Red-700 text.
  - Near Deadline: Amber-100 background, Amber-700 text.
  - Done: Green-100 background, Green-700 text.
- **Accordions:** Clean Slate 200 borders. Use a chevron icon for toggle. When expanded, the background of the header remains Slate 50 to denote the open container.