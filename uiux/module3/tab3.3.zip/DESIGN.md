---
name: 'MKT Hub: Analytic Blueprint'
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#585f6c'
  on-secondary: '#ffffff'
  secondary-container: '#dce2f3'
  on-secondary-container: '#5e6572'
  tertiary: '#943700'
  on-tertiary: '#ffffff'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dce2f3'
  secondary-fixed-dim: '#c0c7d6'
  on-secondary-fixed: '#151c27'
  on-secondary-fixed-variant: '#404754'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  border-subtle: '#E5E7EB'
  text-main: '#111827'
  success-green: '#059669'
  error-red: '#DC2626'
  warning-amber: '#D97706'
  surface-white: '#FFFFFF'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  panel-split: 400px
---

## Brand & Style

The design system for the MKT Hub (Leads & KPIs) is rooted in **Minimalism** and **Corporate Modern** aesthetics. It is designed to function as a high-fidelity wireframe that prioritizes data density, clarity, and analytical focus over decorative elements.

### Brand Personality
- **Precision:** Every pixel serves a functional purpose in the data hierarchy.
- **Objectivity:** A neutral palette ensures that the data (growth, trends, and gaps) is the primary focus.
- **Professionalism:** Systematic spacing and reliable typography evoke trust for stakeholders managing high-value pipelines.

### Visual Style
- **Reduced Visual Noise:** Uses a grayscale foundation to minimize cognitive load during complex data entry and analysis.
- **Functional Color:** Color is reserved exclusively for interactive states (Professional Blue) and semantic indicators (Success Green / Error Red).
- **Structure:** Defined by light borders and subtle tonal layering rather than heavy shadows or complex gradients.

## Colors

The palette is strictly functional, utilizing a monochromatic scale for the UI structure and a single primary blue for primary actions. 

- **Primary Blue:** Used for buttons, active navigation states, and primary interactive elements.
- **Secondary Gray:** Applied to labels, icons, and non-essential text to create hierarchy against the primary content.
- **Neutrals:** `#F9FAFB` serves as the primary canvas background to differentiate from the `#FFFFFF` surfaces of cards and data tables.
- **Semantic Colors:** Success Green, Error Red, and Warning Amber are used sparingly for growth indicators (YoY growth), KPI health (Actual vs Plan), and "Won" status updates.

## Typography

The typography system uses **Inter** for its exceptional legibility in data-dense environments and neutral character. 

- **Data Tables:** Use `body-md` for standard cells and `data-mono` (medium weight Inter) for currency values and numeric counts to ensure vertical alignment and readability.
- **KPI Cards:** Use `headline-md` for primary metrics and `label-bold` for comparison percentages.
- **Hierarchy:** Use `label-caps` for secondary table headers and section overviews to distinguish structural labels from interactive data.
- **Mobile Adjustments:** Headlines above 24px should scale down to 20px on mobile devices to prevent excessive line-wrapping in card layouts.

## Layout & Spacing

This design system employs a **Fixed Grid** philosophy for desktop dashboards to ensure consistent data visualization, transitioning to a fluid stack for mobile.

- **Main Layout:** A 12-column grid with 24px gutters. 
- **Split-Screen Forms:** Used in the "Input Data" tab. The left panel (Plan KPIs) is fixed at `panel-split` width, while the right panel (Actuals) expands to fill the remaining space.
- **KPI Row:** Usually spans 4 or 6 columns per card depending on the screen size, allowing 3-4 cards per row.
- **Vertical Rhythm:** A base 8px unit dictates all padding and margins. Use `stack-sm` for internal component spacing (label to input) and `stack-lg` to separate major sections (Funnel Chart to Pipeline Table).
- **Responsive Behavior:** At the 768px breakpoint, the 2-column form layout stacks vertically, and the Horizontal Funnel Chart should switch to a simplified vertical list or a scaled-down SVG.

## Elevation & Depth

To maintain the "Blueprint/Wireframe" feel, elevation is achieved through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows.

- **Background:** The base level is `#F9FAFB`.
- **Surfaces:** Cards, tables, and form panels use `#FFFFFF` with a 1px border of `#E5E7EB`.
- **Hover States:** Interactive rows or cards use a subtle shift to a slightly darker gray or a thin `primary-blue` left-accent border.
- **Modals/Popovers:** Use a very soft, diffused shadow (0px 4px 12px, 5% opacity) to provide context without breaking the minimalist aesthetic.
- **Dividers:** Use 1px solid `#E5E7EB` for horizontal rules within lists or to separate form sections.

## Shapes

The shape language is **Soft (0.25rem)**, providing a subtle professional touch that avoids the clinical feel of sharp corners while remaining more structured than fully rounded designs.

- **Input Fields & Buttons:** 4px (0.25rem) border-radius.
- **Cards & Panels:** 8px (0.5rem) border-radius to distinguish larger containers from small components.
- **Growth Tags:** Status indicators (e.g., "YoY +12%") use a 4px radius; avoid pill shapes to keep the professional "Blueprint" look.
- **Funnel Bars:** Should have flat ends or a very minimal 2px radius to represent data volume accurately.

## Components

### Buttons
- **Primary:** Background `#2563EB`, white text, 4px radius. Used for "Save Actual Data" or "Save Plan".
- **Ghost/Outline:** `#E5E7EB` border, `#6B7280` text. Used for "Transfer → Won" or secondary navigation within tables.

### Data Tables
- **Header:** Background `#F9FAFB`, `label-caps` text, border-bottom 1px.
- **Cells:** `body-md` for text, `data-mono` for numbers. Row height 48px for standard, 40px for dense data.
- **Success/Error States:** Use subtle text color (Success Green) for growth values; avoid heavy background fills.

### KPI Cards
- **Structure:** 24px internal padding. Large numeric value in `headline-md`. 
- **Comparison Row:** Small text underneath using `body-sm` with colored "Actual vs Plan" indicators.

### Form Fields
- **Inputs:** 1px `#E5E7EB` border, `#F9FAFB` background when disabled. 
- **Labels:** `label-bold` positioned 8px above the input field.
- **Helper Text:** `body-sm` in `#6B7280`.

### Funnel Chart
- **Visuals:** Horizontal bars with decreasing width. Use a gradient of grays or a single subtle blue tint. 
- **Labels:** Place percentage conversion rates between stages using a "chevron" or "arrow" icon.

### Split-Screen Forms
- **divider:** 1px vertical border separating the fixed left "Plan" panel and the flexible right "Actuals" panel.