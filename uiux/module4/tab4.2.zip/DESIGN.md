---
name: Fiscal Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#d9d9e4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3fe'
  surface-container: '#ededf8'
  surface-container-high: '#e7e7f3'
  surface-container-highest: '#e2e1ed'
  on-surface: '#191b23'
  on-surface-variant: '#434654'
  inverse-surface: '#2e3039'
  inverse-on-surface: '#f0f0fb'
  outline: '#737686'
  outline-variant: '#c3c5d7'
  surface-tint: '#1353d8'
  primary: '#003fb1'
  on-primary: '#ffffff'
  primary-container: '#1a56db'
  on-primary-container: '#d4dcff'
  inverse-primary: '#b5c4ff'
  secondary: '#4f5e80'
  on-secondary: '#ffffff'
  secondary-container: '#c7d7fe'
  on-secondary-container: '#4e5d7f'
  tertiary: '#852b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#ad3b00'
  on-tertiary-container: '#ffd4c5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b5c4ff'
  on-primary-fixed: '#00174d'
  on-primary-fixed-variant: '#003dab'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#b7c6ed'
  on-secondary-fixed: '#091b39'
  on-secondary-fixed-variant: '#374767'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#802a00'
  background: '#faf8ff'
  on-background: '#191b23'
  surface-variant: '#e2e1ed'
  danger: '#E02424'
  warning: '#E3A008'
  success: '#057A55'
  scale: '#1C64F2'
  surface-muted: '#F9FAFB'
  border-subtle: '#E5E7EB'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  headline-md-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  container-margin: 24px
  gutter: 16px
  cell-padding-x: 12px
  cell-padding-y: 16px
  section-gap: 32px
---

## Brand & Style

The design system is engineered for high-stakes financial decision-making within a B2B SaaS environment. It targets Marketing Managers and Executives who require immediate, reliable insights into expenditure and customer value.

The visual style is **Corporate / Modern** with a heavy emphasis on **Minimalism**. The interface prioritizes data density without compromising legibility. It evokes a sense of "Operational Excellence"—where every pixel serves a functional purpose. The aesthetic is clean and structured, using generous white space to separate complex data clusters and a refined color palette to signal financial health instantly.

- **Trust:** Established through a systematic, grid-based layout.
- **Clarity:** Achieved via high-contrast typography and intentional use of semantic colors.
- **Efficiency:** Promoted by a "data-first" hierarchy where KPIs and tables are the primary focus.

## Colors

The palette is anchored by **Corporate Blue**, chosen for its association with stability and professional fintech standards. 

- **Primary (#1A56DB):** Used for primary actions, active navigation states, and key interactive elements.
- **Secondary (#0D1E3C):** A deep navy used for text and iconography to ensure high contrast and a premium feel.
- **Semantic Colors (BR-009):** These are strictly reserved for financial health indicators:
    - **Danger (#E02424):** LTV:CAC < 1.5. Used for critical alerts and negative variance.
    - **Warning (#E3A008):** LTV:CAC 1.5–2.5. Indicates areas needing optimization.
    - **Success (#057A55):** LTV:CAC 2.5–4.0. Represents the "Gold Ratio" and positive budget variance.
    - **Scale (#1C64F2):** LTV:CAC > 4.0. Highlights under-investment and growth opportunities.

The default mode is **Light**, utilizing a clean white base with subtle gray surfaces to define content boundaries without adding visual noise.

## Typography

**Inter** is the exclusive typeface for this design system. It is selected for its exceptional legibility in data-heavy environments and its neutral, professional tone.

- **Financial Data:** For tables and KPI metrics, use the `data-mono` variant or enable tabular numbers (`tnum`) to ensure digits align vertically, facilitating easier comparison of currency values.
- **Hierarchy:** Use `label-md` in all-caps for section headers and table column headers to create clear structural separation.
- **Responsiveness:** On mobile devices, `display-lg` scales down to `headline-md-mobile` to maintain layout integrity.
- **Weight:** Avoid using weights below 400 for financial figures to ensure readability across all monitor types.

## Layout & Spacing

This design system employs a **12-column Fluid Grid** for dashboard views, transitioning to a single-column layout for mobile. 

- **Grid Logic:** The layout relies on a 4px base unit. Gutters are fixed at 16px to maintain a tight, professional density suitable for SaaS dashboards.
- **Data Tables:** Tables use a "Compact-Comfortable" hybrid. Horizontal padding is minimized to fit more columns, while vertical padding remains 16px to prevent line-to-line eye strain.
- **Breakpoints:**
    - **Desktop (1280px+):** 12 columns, 24px margins.
    - **Tablet (768px - 1279px):** 6 columns, 16px margins. Sidebar collapses to icons.
    - **Mobile (< 767px):** 1 column, 12px margins. Horizontal scrolling enabled for large data tables.
- **Alignment:** Financial values are always right-aligned in tables to allow for easy decimal/magnitude comparison.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** rather than heavy shadows. This maintains a clean, "flat-modern" look that keeps focus on the data.

- **Layer 0 (Background):** Used for the main application background (#F9FAFB).
- **Layer 1 (Cards/Tables):** Pure white (#FFFFFF) with a 1px solid border (#E5E7EB). No shadow is used for standard cards.
- **Layer 2 (Modals/Dropdowns):** Pure white with a 1px border and a subtle, high-diffusion ambient shadow (Blur 12px, 4% Opacity, #000).
- **Interactive States:** On hover, cards or table rows may use a very light tint of the Primary color (5% opacity) to indicate interactivity without shifting the elevation.

## Shapes

The shape language is **Soft**. This provides a modern, approachable feel while maintaining the structural rigidity expected of a financial tool.

- **Standard Elements:** Buttons, Input fields, and Cards use a 0.25rem (4px) corner radius.
- **Large Components:** Modals and main Dashboard containers use a 0.5rem (8px) corner radius.
- **Status Indicators:** Pills and health indicators use a full "rounded-pill" (999px) radius to distinguish them from actionable buttons.

## Components

- **KPI Cards:** Use a white background with a top-border accent. The main metric should use `display-lg`. The Health Indicator (LTV:CAC) must include both a color-coded pill and a text label (e.g., "🔴 Critical").
- **Data Tables:**
    - Header: `label-md` font, light gray background (#F9FAFB), 1px bottom border.
    - Rows: White background, hover state with 5% Primary color tint.
    - Variance: Use Success green for positive (under budget) and Danger red for negative (over budget).
- **Tabbed Navigation:** Flat style. The active tab is indicated by a 2px bottom border in Primary Blue and a bold font weight.
- **Buttons:**
    - Primary: Solid Primary Blue, white text.
    - Secondary: White background, 1px border (#E5E7EB), Secondary Navy text.
    - Danger: Outline style with Danger red for "Delete" actions.
- **Form Elements:** Inputs must have a 1px border. In the "Nhập chi phí" form, use `prefix` icons for currency (VNĐ) and `suffix` for percentages (%) to minimize user error.
- **Health Indicators:** Always combine color with a secondary visual cue (icons or text) to ensure accessibility for color-blind users.