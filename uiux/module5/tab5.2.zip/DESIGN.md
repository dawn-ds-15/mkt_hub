---
name: Prism 2.0
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1b1b1e'
  surface-container: '#1f1f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e4e1e6'
  on-surface-variant: '#c9c4d7'
  inverse-surface: '#e4e1e6'
  inverse-on-surface: '#303033'
  outline: '#938ea0'
  outline-variant: '#484554'
  surface-tint: '#cabeff'
  primary: '#cabeff'
  on-primary: '#30009a'
  primary-container: '#5d3fd3'
  on-primary-container: '#d8ceff'
  inverse-primary: '#6042d6'
  secondary: '#66dd8b'
  on-secondary: '#003919'
  secondary-container: '#25a55a'
  on-secondary-container: '#003115'
  tertiary: '#ffb59c'
  on-tertiary: '#5c1a00'
  tertiary-container: '#a13a0f'
  on-tertiary-container: '#ffc8b6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e6deff'
  primary-fixed-dim: '#cabeff'
  on-primary-fixed: '#1c0062'
  on-primary-fixed-variant: '#4723be'
  secondary-fixed: '#83fba5'
  secondary-fixed-dim: '#66dd8b'
  on-secondary-fixed: '#00210c'
  on-secondary-fixed-variant: '#005227'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59c'
  on-tertiary-fixed: '#380c00'
  on-tertiary-fixed-variant: '#822800'
  background: '#131316'
  on-background: '#e4e1e6'
  surface-variant: '#353438'
typography:
  display-lg:
    fontFamily: Inter Tight
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter Tight
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter Tight
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Inter Tight
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter Tight
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter Tight
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 24px
  gutter: 16px
  sidebar-width-collapsed: 64px
  sidebar-width-expanded: 240px
  bento-gap: 12px
---

## Brand & Style
The design system is engineered for high-density marketing analytics and cognitive efficiency. It prioritizes a **Dark Mode First** experience, utilizing depth and translucency to manage complex information hierarchies without overwhelming the user. 

The aesthetic is a hybrid of **Glassmorphism** and **Bento Box** layouts—utilizing frosted glass surfaces to maintain context during "Hover-Peek" interactions and modular, rectangular containers to organize disparate data streams. The emotional response is one of professional mastery: precise, technical, and high-performance. All transitions utilize a 200ms spring physics model to feel responsive rather than mechanical.

## Colors
The palette is anchored by **Electric Indigo** for primary actions and **Emerald Mint** for success states and positive growth metrics. The background is a deep, "ink" black to maximize contrast with the glass layers. 

For data visualization, a 12-color accessible palette is provided to ensure legibility for users with color vision deficiencies. Secondary and tertiary accents should be used sparingly for data categorization. Glass surfaces use a subtle white stroke at low opacity to define boundaries against the dark void.

## Typography
This design system uses **Inter Tight** (a condensed variant of Inter) for all UI copy and headings to maintain high density without sacrificing readability. For numerical data, financial tables, and metrics, **JetBrains Mono** (Tabular Monospace) is mandated to ensure vertical alignment of digits across rows.

Display styles use tighter letter spacing and heavy weights to create a "technical" editorial feel. Label styles often use uppercase with increased tracking for clear categorization in tight spaces.

## Layout & Spacing
The layout follows a **Bento Box** grid philosophy, where content is grouped into logical, distinct containers of varying sizes. A 12-column fluid grid is used for the main dashboard area, while the sidebar remains a fixed-width collapsible element.

- **Desktop:** 24px outer margins, 16px gutters between major sections.
- **Bento Grid:** Containers within modules use a tighter 12px gap to emphasize their relationship.
- **Sidebar:** Collapses to 64px (icons only) to maximize workspace; expands to 240px for full navigation.
- **Density:** Components use a 4px base unit to allow for compact, data-rich interfaces.

## Elevation & Depth
Depth is created through **Glassmorphism** and tonal stacking rather than traditional shadows.

1.  **Level 0 (Base):** Deep black background (#050505).
2.  **Level 1 (Bento Cells):** Solid dark grey (#16161A) with a 1px border at 8% opacity.
3.  **Level 2 (Modals/Overlays):** Translucent glass (Backdrop Blur: 20px, Fill: White 4%). 
4.  **Level 3 (Hover-Peek):** High-contrast glass (Backdrop Blur: 40px, Fill: White 8%) used for temporary tooltips or contextual data previews that "float" above the grid.

All elevated elements use a "top-light" gradient stroke (lighter at the top, fading at the bottom) to simulate a subtle physical presence.

## Shapes
The design system utilizes a **Soft** shape language to balance the "hard" technical nature of the data. 

- **Cards/Bento Cells:** Use `rounded-lg` (0.5rem) for a modern, contained look.
- **Inputs/Buttons:** Use base `rounded` (0.25rem) to maintain a precise, professional feel.
- **Tags/Status Pills:** Use full `rounded-xl` for distinct contrast against the rectangular grid.

## Components

### Buttons
- **Primary:** Solid Electric Indigo with white text. Subtle inner glow on hover.
- **Ghost:** Transparent background with Indigo stroke. High-blur glass effect on hover.

### Bento Cards
- Containers for data modules. Must have a subtle 1px border and a background slightly lighter than the page base. Headers within cards use `label-caps` typography.

### Hover-Peek Tooltips
- Activated on hover over data points. These use the highest glassmorphism blur and contain secondary metrics. Transition in via a 200ms spring scale (from 95% to 100%).

### Input Fields
- Dark, inset backgrounds. On focus, the border glows with a 2px Electric Indigo soft outer stroke. Use `data-mono` for numerical inputs.

### Collapsible Sidebar
- Slim profile. Active states are indicated by a vertical Electric Indigo bar on the left edge and a subtle background tint.

### Data Tables
- High-density rows. Alternating row highlights using 2% white transparency. Header cells are pinned and use a heavier glass blur to maintain legibility when scrolling.